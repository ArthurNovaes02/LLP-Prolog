rotacionar(0,[_],L).

rotacionar(N). :- rotacionar(N-1,,)
